const express = require('express');
const app = express();
const port = 1010;





app.get('/',(req,res)=>{

    res.render('home')
})

app.get('/one',(req,res)=>{

    res.render('one')
})
app.get('/two',(req,res)=>{

    res.render('two')
})
app.get('/three',(req,res)=>{

    res.render('three')
})
app.get('/four',(req,res)=>{

    res.render('four')
})
app.get('/five',(req,res)=>{

    res.render('five')
})



app.listen(port,()=> {
    console.log('Running on localhost:1010')
})


