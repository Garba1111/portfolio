const express = require('express');
const app = express();
const port = 10100;


const db_bookstore=[
    {
        id:1,
        Tittle:'',
        Author:'',
        Subject:''
    },
    {
        id:1,
        Tittle:'',
        Author:'',
        Subject:''
    },{
        id:1,
        Tittle:'',
        Author:'',
        Subject:''
    }
]


app.get('/',(req,res)=>{

    res.render('home')
})

app.get('/one',(req,res)=>{

    res.render('one')
})
app.get('/two',(req,res)=>{

    res.render('two')
})
app.get('/three',(req,res)=>{

    res.render('three')
})
app.get('/four',(req,res)=>{

    res.render('four')
})
app.get('/five',(req,res)=>{

    res.render('five')
})
app.get('/items',(req,res)=>{

    res.render('items')
})



app.listen(port,()=> {
    console.log('Running on localhost:10100')
})


